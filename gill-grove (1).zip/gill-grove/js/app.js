// Gill & Grove: shared script. Each page runs only its own init.
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const PAGES=[["index.html","Home"],["learn.html","Learn"],["explore.html","Explorer"],["quiz.html","Quiz"]];
const SPECIES=[
{n:"Death cap",l:"Amanita phalloides",h:"Woodland",r:"Deadly",c:"#9aa06a",s:"#efe9d2",t:"Linked to most fatal mushroom poisonings. Symptoms can be delayed 6 to 24 hours, so feeling fine after eating proves nothing.",p:[40,52]},
{n:"Fly agaric",l:"Amanita muscaria",h:"Woodland",r:"Toxic",c:"#c8321f",s:"#f4efe0",t:"A red cap with white flecks. Poisonous, though rarely fatal. Rain can wash the flecks off, so never rely on colour alone.",p:[76,62]},
{n:"Chanterelle",l:"Cantharellus cibarius",h:"Woodland",r:"Edible with care",c:"#e0a526",s:"#e9c565",t:"Has forking ridges rather than true gills. Toxic look-alikes exist, such as the jack-o'-lantern mushroom.",p:[128,52]},
{n:"Morel",l:"Morchella",h:"Woodland",r:"Edible with care",c:"#8a6a3a",s:"#eadfc6",t:"Hollow from tip to base. Never eat raw. It can be confused with false morels, which may contain toxins.",p:[56,100]},
{n:"Giant puffball",l:"Calvatia gigantea",h:"Grassland",r:"Edible with care",c:"#f1ecdf",s:"#f1ecdf",t:"Only firm, pure white flesh all the way through is acceptable, so cut every puffball in half. Young deadly Amanita buttons can look like small puffballs.",p:[132,102]},
{n:"Shaggy mane",l:"Coprinus comatus",h:"Grassland",r:"Edible with care",c:"#d9d2c0",s:"#f4f0e4",t:"Turns to black ink within hours of picking, so it must be cooked fresh. Pick only young, firm specimens.",p:[102,30]}];
const SAFE="Never eat a wild mushroom because of anything on this website. Have a qualified local expert confirm every identification.";
function shell(){const cur=location.pathname.split("/").pop()||"index.html";
document.body.insertAdjacentHTML("afterbegin",`<div class="safety" role="note"><b>Safety first:</b> ${SAFE}</div><nav><div class="wrap"><a class="brand" href="index.html">Gill &amp; Grove</a>${PAGES.map(([h,t])=>`<a class="l" href="${h}"${h===cur?' aria-current="page"':''}>${t}</a>`).join("")}</div></nav>`);
document.body.insertAdjacentHTML("beforeend",`<footer><div class="wrap"><b>Gill &amp; Grove</b><p>An educational prototype about mushroom foraging. Illustrations are original drawings; facts are general and not a field guide.</p>${PAGES.map(([h,t])=>`<a href="${h}">${t}</a>`).join("")}</div></footer>`)}
function chips(el,items,cb){el.innerHTML=items.map((t,i)=>`<button type="button" class="chip" aria-pressed="${i==0}">${t}</button>`).join("");el.onclick=e=>{const b=e.target.closest(".chip");if(!b)return;$$(".chip",el).forEach(x=>x.setAttribute("aria-pressed",x===b));cb(b.textContent)}}
const tagc=r=>r=="Deadly"?"d":r=="Toxic"?"t":"";
function initExplore(){let h="All",r="All";const g=$("#grid");function draw(){const l=SPECIES.filter(s=>(h=="All"||s.h==h)&&(r=="All"||s.r==r));$("#cnt").textContent=l.length+" of "+SPECIES.length+" species shown";
g.innerHTML=l.map(s=>`<article class="card"><span class="tag ${tagc(s.r)}">${s.r}</span><h3>${s.n}</h3><i>${s.l}</i><div>Habitat: ${s.h}</div><p>${s.t}</p></article>`).join("")||"<p>No species match both filters.</p>"}
chips($("#fh"),["All","Woodland","Grassland"],v=>{h=v;draw()});chips($("#fr"),["All","Edible with care","Toxic","Deadly"],v=>{r=v;draw()});draw()}
const QS=[["Squirrels and slugs eat a mushroom. Is it safe for you?",["Yes, animals know what is safe","No, animals handle toxins differently from people"],1,"Animals digest many toxins that harm people, so this is a myth."],
["Which is the safest rule?",["Eat it if it looks like a picture","Eat only what a qualified expert has confirmed"],1,"Photos and apps are not enough. Experts check the whole specimen."],
["When do death cap symptoms usually appear?",["Within minutes","Often 6 to 24 hours later"],1,"The delay is why feeling well after eating is not proof of safety."],
["Does cooking make every poisonous mushroom safe?",["Yes","No, many toxins survive cooking"],1,"Some toxins are not destroyed by heat."],
["Why should you collect the whole mushroom, including the base?",["Features at the base help identification","It looks tidier"],0,"A cup-like base (volva) is a key clue for some deadly species."]];
function initQuiz(){let i=0,sc=0,done=false;const b=$("#qb");function show(){if(i>=QS.length){b.innerHTML=`<h2>You scored ${sc} out of ${QS.length}</h2><p>${sc>=4?"Great work.":"Review the Learn page and try again."} Remember: ${SAFE}</p><button class="btn" id="re">Restart</button>`;$("#re").onclick=()=>{i=0;sc=0;show()};return}
const q=QS[i];done=false;b.innerHTML=`<p>Question ${i+1} of ${QS.length}</p><div class="prog"><i style="width:${(i+1)/QS.length*100}%"></i></div><h2 style="margin-top:16px">${q[0]}</h2>${q[1].map((t,k)=>`<button class="opt" data-k="${k}">${t}</button>`).join("")}<p id="fb" role="status"></p><button class="btn" id="nx" disabled>${i==QS.length-1?"See score":"Next"}</button>`;
b.onclick=e=>{const o=e.target.closest(".opt");if(o&&!done){done=true;const k=+o.dataset.k;if(k==q[2])sc++;$$(".opt",b).forEach((x,n)=>{if(n==q[2])x.classList.add("ok")});o.classList.add(k==q[2]?"ok":"no");$("#fb").textContent=(k==q[2]?"Correct. ":"Not quite. ")+q[3];$("#nx").disabled=false}
if(e.target.id=="nx"){i++;show()}}}show()}
document.addEventListener("DOMContentLoaded",()=>{shell();({explore:initExplore,quiz:initQuiz}[document.body.dataset.p]||(()=>{}))()});
